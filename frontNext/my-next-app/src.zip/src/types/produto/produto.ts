// src/types/produto.ts
export interface Produto {
  id: number
  nome: string
  marca: string
  modelo: string
  preco: number
  descricao: string
}
