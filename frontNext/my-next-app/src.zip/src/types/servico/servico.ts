export interface Servico {
  id: number
  nome: string
  valor: number
  descricao: string
}